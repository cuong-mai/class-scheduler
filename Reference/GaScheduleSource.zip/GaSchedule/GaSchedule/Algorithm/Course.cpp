
////////////////////////////////////
// (C)2007-2008 Coolsoft Company. //
// All rights reserved.           //
// http://www.coolsoft-sd.com     //
// Licence: licence.txt           //
////////////////////////////////////

#include "stdafx.h"
#include "Course.h"

// Initializes course
Course::Course(int id, const string& name) : _id(id),
											 _name(name) { }

